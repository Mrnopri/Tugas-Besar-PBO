level_0 = {
        'terrain': 'level/1/level_00_terrain.csv',
        'coins': 'level/1/level_00_coins.csv',
        'crates': 'level/1/level_00_crates.csv',
        'enemies': 'level/1/level_00_enemies.csv',
        'constraints': 'level/1/level_00_constraints.csv',
        'player': 'level/1/level_00_player.csv',
        'bg_palms': 'level/1/level_00_bg_palms.csv',
}