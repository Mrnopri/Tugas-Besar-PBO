<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="bgtree" tilewidth="108" tileheight="312" tilecount="2" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="108" height="312" source="../../graphics/terrain/Tree_bg/tree1.png"/>
 </tile>
 <tile id="1">
  <image width="88" height="144" source="../../graphics/terrain/Tree_bg/tree2.png"/>
 </tile>
</tileset>
